<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>Home</name>
    <message>
        <location filename="../home.ui" line="14"/>
        <source>Internacionalizacion</source>
        <translation>Internacionalizacion</translation>
    </message>
    <message>
        <location filename="../home.ui" line="26"/>
        <source>Escoger Idioma</source>
        <translation>Escoger Idioma</translation>
    </message>
    <message>
        <location filename="../home.ui" line="49"/>
        <source>Nombre: </source>
        <translation>Nombre: </translation>
    </message>
    <message>
        <location filename="../home.ui" line="72"/>
        <source>Apellido:</source>
        <translation>Apellido:</translation>
    </message>
    <message>
        <location filename="../home.ui" line="95"/>
        <source>Genero:</source>
        <translation>Genero:</translation>
    </message>
    <message>
        <location filename="../home.ui" line="108"/>
        <location filename="../home.cpp" line="65"/>
        <source>Femenino</source>
        <translation>Femenino</translation>
    </message>
    <message>
        <location filename="../home.ui" line="121"/>
        <location filename="../home.cpp" line="65"/>
        <source>Masculino</source>
        <translation>Masculino</translation>
    </message>
    <message>
        <location filename="../home.ui" line="134"/>
        <source>Mostrar Mensaje</source>
        <translation>Mostrar Mensaje</translation>
    </message>
    <message>
        <location filename="../home.ui" line="147"/>
        <source>Mensaje</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <location filename="../home.ui" line="160"/>
        <source>Nivel:</source>
        <translation>Nivel:</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="27"/>
        <source>English</source>
        <translation>Ingles</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="26"/>
        <source>Español</source>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="34"/>
        <source>Primero</source>
        <translation>Primero</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="35"/>
        <source>Segundo</source>
        <translation>Segundo</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="36"/>
        <source>Tercero</source>
        <translation>Tercero</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="37"/>
        <source>Cuarto</source>
        <translation>Cuarto</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="38"/>
        <source>Quinto</source>
        <translation>Quinto</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="39"/>
        <source>Sexto</source>
        <translation>Sexto</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="40"/>
        <source>Séptimo</source>
        <translation>Séptimo</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="41"/>
        <source>Octavo</source>
        <translation>Octavo</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="69"/>
        <source>INFORMACION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../home.cpp" line="69"/>
        <source>Debe llenar todos los campos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../home.cpp" line="71"/>
        <source>Bienvenido</source>
        <translation>Bienvenido</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="71"/>
        <source>Bienvenido </source>
        <translation>Bienvenido </translation>
    </message>
</context>
</TS>
