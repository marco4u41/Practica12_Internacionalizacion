<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Home</name>
    <message>
        <location filename="../home.ui" line="14"/>
        <source>Internacionalizacion</source>
        <translation type="unfinished">Internationalization</translation>
    </message>
    <message>
        <location filename="../home.ui" line="26"/>
        <source>Escoger Idioma</source>
        <translation>Choose Lenguage</translation>
    </message>
    <message>
        <location filename="../home.ui" line="49"/>
        <source>Nombre: </source>
        <translation>Name: </translation>
    </message>
    <message>
        <location filename="../home.ui" line="72"/>
        <source>Apellido:</source>
        <translation>Last name:</translation>
    </message>
    <message>
        <location filename="../home.ui" line="95"/>
        <source>Genero:</source>
        <translation>Genre:</translation>
    </message>
    <message>
        <location filename="../home.ui" line="108"/>
        <location filename="../home.cpp" line="65"/>
        <source>Femenino</source>
        <translation>Femenine</translation>
    </message>
    <message>
        <location filename="../home.ui" line="121"/>
        <location filename="../home.cpp" line="65"/>
        <source>Masculino</source>
        <translation>Masculine</translation>
    </message>
    <message>
        <location filename="../home.ui" line="134"/>
        <source>Mostrar Mensaje</source>
        <translation>Show Message</translation>
    </message>
    <message>
        <location filename="../home.ui" line="147"/>
        <source>Mensaje</source>
        <translation>Message</translation>
    </message>
    <message>
        <location filename="../home.ui" line="160"/>
        <source>Nivel:</source>
        <translation>Level:</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="27"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="26"/>
        <source>Español</source>
        <translation>Español</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="34"/>
        <source>Primero</source>
        <translation>First</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="35"/>
        <source>Segundo</source>
        <translation>Second</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="36"/>
        <source>Tercero</source>
        <translation>Third</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="37"/>
        <source>Cuarto</source>
        <translation>Fourth</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="38"/>
        <source>Quinto</source>
        <translation>Fifth</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="39"/>
        <source>Sexto</source>
        <translation>sixth</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="40"/>
        <source>Séptimo</source>
        <translation>seventh</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="41"/>
        <source>Octavo</source>
        <translation>Eighth</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="71"/>
        <source>Bienvenido</source>
        <translation>Welcome</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="71"/>
        <source>Bienvenido </source>
        <translation>Welcome </translation>
    </message>
    <message>
        <location filename="../home.cpp" line="69"/>
        <source>Debe llenar todos los campos</source>
        <translation>Please fill in all fields</translation>
    </message>
    <message>
        <location filename="../home.cpp" line="69"/>
        <source>INFORMACION</source>
        <translation>INFORMATION</translation>
    </message>
</context>
</TS>
