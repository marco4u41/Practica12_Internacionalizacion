#ifndef HOME_H
#define HOME_H

#include <QWidget>
#include <QTranslator>
#include <QPixmap>

QT_BEGIN_NAMESPACE
namespace Ui {
class Home;
}
QT_END_NAMESPACE

class Home : public QWidget
{
    Q_OBJECT

public:
    Home(QWidget *parent = nullptr);
    ~Home();

private:
    Ui::Home *ui;
    QTranslator translator;
    void cargarIdiomas();
    void cargarNiveles();
    void cambiarIdioma(int index);




private slots:
    void desplegarMensaje();
};
#endif // HOME_H
