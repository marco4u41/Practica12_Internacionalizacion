#include <QApplication>
#include "home.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    QTranslator translator;
    // Set the default language
    if (translator.load(":/translations/app_en")) {
        a.installTranslator(&translator);
    }

    Home w;
    w.show();
    return a.exec();
}
