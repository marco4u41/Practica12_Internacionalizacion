#include "home.h"
#include "ui_home.h"
#include <QMessageBox>
#include <QApplication>
#include <QDebug> // Agregado para depuración
#include <QPixmap>


Home::Home(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Home)
{
    ui->setupUi(this);

    cargarIdiomas();
    cargarNiveles();
    connect(ui->btn_Mensajes, &QPushButton::clicked, this, &Home::desplegarMensaje);
    connect(ui->cmb_Idiomas, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &Home::cambiarIdioma);

}

Home::~Home()
{
    delete ui;
}

void Home::cargarIdiomas()
{
    ui->cmb_Idiomas->addItem(tr("Español"), "es");
    ui->cmb_Idiomas->addItem(tr("English"), "en");

}

void Home::cargarNiveles()
{
    ui->cmb_Niveles->clear(); // Limpia el comboBox antes de agregar los niveles
    ui->cmb_Niveles->addItem(tr("Primero"));
    ui->cmb_Niveles->addItem(tr("Segundo"));
    ui->cmb_Niveles->addItem(tr("Tercero"));
    ui->cmb_Niveles->addItem(tr("Cuarto"));
    ui->cmb_Niveles->addItem(tr("Quinto"));
    ui->cmb_Niveles->addItem(tr("Sexto"));
    ui->cmb_Niveles->addItem(tr("Séptimo"));
    ui->cmb_Niveles->addItem(tr("Octavo"));
}

void Home::cambiarIdioma(int index)
{
    QString idioma = ui->cmb_Idiomas->itemData(index).toString();
    QString archivoTrad = "C:/Users/USER/Desktop/PRACTICA/Practica12_Internacionalizacion/translations/app_" + idioma + ".qm";

    if (translator.load(archivoTrad)) {
        qApp->removeTranslator(&translator); // Remueve el traductor anterior si existe
        qApp->installTranslator(&translator); // Instala el nuevo traductor
        ui->retranslateUi(this); // Actualiza los textos en la interfaz
        cargarNiveles(); // Recarga los niveles traducidos
        qDebug() << "Idioma cambiado a:" << idioma;
    } else {
        qDebug() << "No se pudo cargar el archivo de traducción:" << archivoTrad;
    }
}




void Home::desplegarMensaje()
{
    QString genero = ui->rdbtn_Femenino->isChecked() ? tr("Femenino") : tr("Masculino");
    QString nombre = ui->txt_Nombre->text();
    QString apellido = ui->txt_Apellido->text();
    if (nombre.isEmpty() && apellido.isEmpty()){
        QMessageBox::information(this,tr("INFORMACION"), tr("Debe llenar todos los campos"));
    }else{
        QMessageBox::information(this, tr("Bienvenido"), tr("Bienvenido ") + nombre + " " + apellido);
    }

}
